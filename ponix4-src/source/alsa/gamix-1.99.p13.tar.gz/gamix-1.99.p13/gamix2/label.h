N_("Capture")
N_("Playback")
