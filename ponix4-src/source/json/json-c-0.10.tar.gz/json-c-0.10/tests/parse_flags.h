#ifndef __parse_flags_h
#define __parse_flags_h
int parse_flags(int argc, char **argv);
#endif
