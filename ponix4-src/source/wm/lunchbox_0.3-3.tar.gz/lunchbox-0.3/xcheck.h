#include <X11/Xlib.h>

Bool
xcheck_raisewin(Display *display, Window window);

Bool
xcheck_setpixmap (Display *display, Window window, Pixmap pixmap);

Bool
xcheck_map(Display *display, Window window);
