/* aewm - a minimalist X11 window mananager. vim:sw=4:ts=4:et
 *
 * Copyright 1998-2006 Decklin Foster <decklin@red-bean.com>. This
 * program is free software; please see LICENSE for details. */

#ifndef AEWM_PARSER_H
#define AEWM_PARSER_H

int get_token(char **, char *);

#endif /* AEWM_PARSER_H */
