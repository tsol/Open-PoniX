#include <cardmon.h>

int
main(int argc, char **argv)
{
	CARD_DATA cd;
	PCARD_DATA pcd;

	memset(pcd, 0, sizeof(cd));

	return 0;
}
