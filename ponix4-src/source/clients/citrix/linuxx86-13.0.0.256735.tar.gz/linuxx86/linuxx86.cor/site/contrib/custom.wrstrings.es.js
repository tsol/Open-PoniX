(function ($) {
    $.localization.customStringBundle('es', {
        Example1: 'Esto es un ejemplo',
        Example2: 'Esto es otro ejemplo',
        RefreshApps: 'Actualizar aplicaciones',
        Accounts: 'Cuentas',
        Preferences: 'Preferencias...',
        ConnCenter: 'Central de conexiones',
        About: 'Acerca de'
    });
})(jQuery);
