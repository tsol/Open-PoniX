(function ($) {
    $.localization.customStringBundle('fr', {
        Example1: 'Exemple',
        Example2: 'Autre exemple',
        RefreshApps: 'Actualiser les applications',
        Accounts: 'Comptes',
        Preferences: 'Préférences...',
        ConnCenter: 'Centre de connexion',
        About: 'À propos de'
    });
})(jQuery);
