/*
 *
 *  Copyright (C) 2007-2014 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIIlIIlI
#define lIIIlIIlI
#ifdef _USBD_ENABLE_VHCI_
#include "usbdcdev.h"
struct llIll*lIlIlIIIl(struct IIIII*lllIlIIIl);void llIllIII(struct llIll*lllll)
;
#endif 
#endif 

