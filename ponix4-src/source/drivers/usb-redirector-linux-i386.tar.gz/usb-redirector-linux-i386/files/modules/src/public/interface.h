/*
 *
 *  Copyright (C) 2007-2014 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef llllIIIII
#define llllIIIII
#define IlIllll 			(1024L*1024L+4096L) 



#define IIlIIllll	(0xb96+1870-0x12e4)
#define lIIIIIIIl	(0xb90+2667-0x15fa)



#define IIIllIIlI	(0x1a98+3043-0x267b)
#define lIIlIlllI		(0x4b1+2348-0xddc)
#define IIlIlIIll		(0x14e7+1235-0x19b8)
#define llIIIlIII		(0x73a+2264-0x100f)
#define lIlIlllII		(0x98c+849-0xcda)



#define IllIlllIl				(0xc61+2944-0x17e0)	
#define IllllIlIl		(0x17e3+2359-0x2118)	
#define IIlllIIII			(0x581+7230-0x21bb)	




#endif 

