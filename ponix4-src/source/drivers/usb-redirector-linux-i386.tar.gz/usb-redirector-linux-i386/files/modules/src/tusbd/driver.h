/*
 *
 *  Copyright (C) 2007-2014 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIlllllI
#define lIIlllllI
extern struct llIll*Illllll;extern int IIIlIlIl;extern struct usb_driver 
IllIIIll;extern int lIIIIIII;
#ifdef _USBD_ENABLE_STUB_
extern spinlock_t lIlIlIl;extern struct list_head IIllIIl;
#endif
#endif 

