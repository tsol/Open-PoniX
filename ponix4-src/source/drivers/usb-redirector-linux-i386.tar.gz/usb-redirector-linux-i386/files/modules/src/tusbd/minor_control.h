/*
 *
 *  Copyright (C) 2007-2014 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IIIIlllII
#define IIIIlllII
#include "usbdcdev.h"
struct llIll*IIlIllIl(void);void lllIlIlIl(struct llIll*lllll);int lllIlIlI(
struct llIll*lllll,const char*IllllI);
#endif 

