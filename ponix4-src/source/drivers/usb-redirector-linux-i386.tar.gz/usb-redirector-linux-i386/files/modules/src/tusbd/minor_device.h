/*
 *
 *  Copyright (C) 2007-2014 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIIIIlII
#define lIIIIIlII
#ifdef _USBD_ENABLE_STUB_
#include "usbdcdev.h"
struct llIll*IIlIIllI(struct IllII*IlIlI);void lIIIIIIlI(struct llIll*IIlII);
#endif 
#endif 

